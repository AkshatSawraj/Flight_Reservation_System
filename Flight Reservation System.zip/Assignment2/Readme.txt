-------------------------------------------------------Travel Agency System-----------------------------------------------------------------

This program is a flight reservation management system build to help the travel agency to improve their system
by increase their productivity and services. In order to track the program, it divided into two section. The first one 
is a Back-End Functional which is the hard code placed into the files. The second one is a Front-End GUI Funtional 
the user can interact with the Graphical User Interface(GUI) and use the funtional that provided by the system.

The usre can search for a flight by choose From and To combo box option and find the suitable flight and booked.
Aslo, the user can search or update for a reservation already made by searching for the client name, reservation code, 
or the name of the airline. In order to run the program you can run it into two ways:

1) Running by using the jar file through this command:  java -jar Akshat-Sawraj.Prince.Bansal.Nagi.Nabal.jar
2) Running by using the Eclipse Editor.

-------------------------------------------------------------------
Date: March 27th, 2021
Authors: Prince Bansal, Akshat Sawraj, Nagi Nabal.